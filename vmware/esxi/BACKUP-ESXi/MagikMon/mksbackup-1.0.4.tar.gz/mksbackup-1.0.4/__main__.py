#!/usr/bin/env python
# mksbackup -- frontent for popular Windows and Linux backup tools
# Copyright (C) Alain Spineux <alain.spineux@gmail.com>
# This program is licensed under the GNU General Public License (GPL)
#
# See http://www.magikmon.com/mksbackup for more information

import sys
import mksbackuplib

if __name__ == "__main__" and not globals().has_key('__no_execute__'):
    sys.exit(mksbackuplib.main())

